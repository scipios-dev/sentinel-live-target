export function greeting(name) {
  return `hi ${name}`;
}
